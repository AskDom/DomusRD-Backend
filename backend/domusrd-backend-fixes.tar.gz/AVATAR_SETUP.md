# Setup de Avatares con Cloudinary

## ¿Por qué Cloudinary?

- ✅ No ocupas espacio en tu servidor
- ✅ Escalable (funciona igual en producción)
- ✅ URLs permanentes incluso si cambias de servidor
- ✅ Tier gratuito generoso (25GB de almacenamiento)
- ✅ Fácil integración

---

## 1️⃣ Crear cuenta en Cloudinary

1. Ve a https://cloudinary.com/users/register/free
2. Crea tu cuenta con email y contraseña
3. En el dashboard, encuentra:
   - **Cloud Name** (en la URL: `https://cloudinary.com/console/c/...`)
   - **API Key** (en Settings > API Keys)
   - **API Secret** (en Settings > API Keys)

---

## 2️⃣ Actualizar tu `.env`

```env
# Base de datos PostgreSQL
DATABASE_URL="postgresql://..."

# JWT
JWT_SECRET="tu-secreto"
JWT_EXPIRES_IN="7d"

# Servidor
PORT=5000
NODE_ENV=development
FRONTEND_URL="http://localhost:3000"

# ✨ CLOUDINARY (Reemplaza con tus valores reales)
CLOUDINARY_CLOUD_NAME="tu-cloud-name"
CLOUDINARY_API_KEY="tu-api-key"
CLOUDINARY_API_SECRET="tu-api-secret"
```

---

## 3️⃣ Instalar dependencias nuevas

```bash
cd backend
npm install cloudinary multer
```

---

## 4️⃣ Migración de BD

```bash
npx prisma migrate dev --name add_avatar_to_user
```

---

## 5️⃣ Endpoints disponibles

### Registrarse CON avatar

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: multipart/form-data" \
  -F "name=Juan Pérez" \
  -F "email=juan@test.com" \
  -F "password=123456" \
  -F "role=VENDEDOR" \
  -F "avatar=@/ruta/a/foto.jpg"
```

**Response:**
```json
{
  "message": "Usuario creado con éxito",
  "user": {
    "id": "abc123",
    "email": "juan@test.com",
    "name": "Juan Pérez",
    "avatar": "https://res.cloudinary.com/.../avatar123.jpg",
    "role": "VENDEDOR"
  },
  "token": "eyJhbGc..."
}
```

### Actualizar avatar

```bash
curl -X PUT http://localhost:5000/api/auth/avatar \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: multipart/form-data" \
  -F "avatar=@/ruta/a/nueva-foto.jpg"
```

**Response:**
```json
{
  "message": "Avatar actualizado",
  "user": { ... },
  "avatar": "https://res.cloudinary.com/.../avatar456.jpg"
}
```

### Obtener usuario actual (con avatar)

```bash
curl -X GET http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer <token>"
```

---

## 🎯 Cómo usar desde el frontend

En `src/services/api.js`:

```javascript
// Registro con avatar
const registerWithAvatar = async (userData, avatarFile) => {
  const formData = new FormData();
  formData.append("name", userData.name);
  formData.append("email", userData.email);
  formData.append("password", userData.password);
  formData.append("role", userData.role);
  if (avatarFile) formData.append("avatar", avatarFile);

  const response = await fetch("/api/auth/register", {
    method: "POST",
    body: formData,  // ¡No incluyas Content-Type, el navegador lo hace!
  });
  return response.json();
};

// Actualizar avatar
const updateAvatar = async (avatarFile, token) => {
  const formData = new FormData();
  formData.append("avatar", avatarFile);

  const response = await fetch("/api/auth/avatar", {
    method: "PUT",
    headers: { "Authorization": `Bearer ${token}` },
    body: formData,
  });
  return response.json();
};
```

---

## ⚠️ Limitaciones por defecto

- **Tamaño máximo:** 5MB
- **Formatos permitidos:** JPEG, PNG, WebP
- **Carpeta en Cloudinary:** `/domusrd/avatars/`

Para cambiar, edita `src/middleware/upload.middleware.js`

---

## 🐛 Troubleshooting

**Error: "CLOUDINARY_CLOUD_NAME is not defined"**
→ Verifica que tu `.env` tenga los valores correctos

**Error: "ENOENT: no such file or directory, open 'tmp/...'"**
→ Crea la carpeta `tmp/`: `mkdir backend/tmp`

**La foto se sube pero el usuario no se crea**
→ Revisa que tu DATABASE_URL esté correcta en `.env`

---

¿Necesitas ayuda?
