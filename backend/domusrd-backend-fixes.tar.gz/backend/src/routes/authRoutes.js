const express = require("express");
const path = require("path");
const { register, login, me, updateAvatar } = require(path.join(__dirname, "..", "controllers", "auth.controller.js"));
const { requireAuth } = require(path.join(__dirname, "..", "middleware", "auth.middleware.js"));
const upload = require(path.join(__dirname, "..", "middleware", "upload.middleware.js"));

const router = express.Router();

router.post("/register", upload.single("avatar"), register);
router.post("/login", login);
router.get("/me", requireAuth, me);
router.put("/avatar", requireAuth, upload.single("avatar"), updateAvatar);

module.exports = router;