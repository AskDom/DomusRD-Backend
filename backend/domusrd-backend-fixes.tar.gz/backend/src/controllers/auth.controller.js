const prisma = require("../config/prisma");
const bcrypt = require("bcryptjs");
const fs = require("fs").promises;
const { generateToken } = require("../utils/jwt");
const { uploadImage, deleteImage } = require("../utils/cloudinary");

const VALID_ROLES = ["CLIENTE", "VENDEDOR", "AGENTE"];

// Quita el password antes de enviar al frontend
function sanitizeUser(user) {
  const { password, ...rest } = user;
  return rest;
}

// 1. REGISTRO DE USUARIOS
const register = async (req, res) => {
  try {
    const { email, password, name, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: "Nombre, correo y contraseña son requeridos" });
    }

    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return res.status(409).json({ error: "El correo ya está registrado" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const finalRole = VALID_ROLES.includes(role) ? role : "CLIENTE";

    // Subir avatar si viene en la request
    let avatarUrl = null;
    if (req.file) {
      try {
        avatarUrl = await uploadImage(req.file.path, "avatars");
        await fs.unlink(req.file.path);  // Elimina archivo temporal
      } catch (uploadError) {
        console.error("Error al subir avatar:", uploadError);
        // Continúa aunque falle la foto, no impide el registro
      }
    }

    const newUser = await prisma.user.create({
      data: { email, name, password: hashedPassword, role: finalRole, avatar: avatarUrl }
    });

    const token = generateToken(newUser);

    res.status(201).json({
      message: "Usuario creado con éxito",
      user: sanitizeUser(newUser),
      token
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al registrar usuario" });
  }
};

// 2. LOGIN DE USUARIOS
const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Correo y contraseña son requeridos" });
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(401).json({ error: "Credenciales incorrectas" });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: "Credenciales incorrectas" });
    }

    const token = generateToken(user);

    res.json({
      message: "Login exitoso",
      user: sanitizeUser(user),
      token
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al iniciar sesión" });
  }
};

// 3. GET USUARIO ACTUAL
const me = async (req, res) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user) {
      return res.status(404).json({ error: "Usuario no encontrado" });
    }
    res.json({ user: sanitizeUser(user) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al obtener usuario" });
  }
};

// 4. ACTUALIZAR AVATAR (nuevo)
const updateAvatar = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No se proporcionó archivo de imagen" });
    }

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    // Eliminar avatar anterior si existe
    if (user.avatar) {
      await deleteImage(user.avatar);
    }

    // Subir nuevo avatar
    const newAvatarUrl = await uploadImage(req.file.path, "avatars");
    await fs.unlink(req.file.path);  // Elimina archivo temporal

    // Actualizar usuario
    const updatedUser = await prisma.user.update({
      where: { id: req.user.id },
      data: { avatar: newAvatarUrl }
    });

    res.json({
      message: "Avatar actualizado",
      user: sanitizeUser(updatedUser),
      avatar: newAvatarUrl
    });
  } catch (error) {
    console.error(error);
    // Limpia el archivo temporal si existe
    if (req.file) {
      try {
        await fs.unlink(req.file.path);
      } catch (e) {}
    }
    res.status(500).json({ error: "Error al actualizar avatar" });
  }
};

module.exports = { register, login, me, updateAvatar };
