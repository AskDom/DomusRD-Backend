const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Sube una imagen a Cloudinary y retorna la URL
async function uploadImage(filePath, folder) {
  try {
    const result = await cloudinary.uploader.upload(filePath, {
      folder: `domusrd/${folder}`,  // Organiza en carpetas: domusrd/avatars, domusrd/properties
      resource_type: "auto",
    });
    return result.secure_url;  // URL HTTPS de la imagen
  } catch (error) {
    console.error("Error subiendo a Cloudinary:", error);
    throw error;
  }
}

// Elimina una imagen de Cloudinary
async function deleteImage(imageUrl) {
  try {
    // Extrae el public_id de la URL
    const publicId = imageUrl.split("/").pop().split(".")[0];
    const fullPath = `domusrd/${publicId}`;
    
    await cloudinary.uploader.destroy(fullPath);
  } catch (error) {
    console.error("Error eliminando de Cloudinary:", error);
  }
}

module.exports = { uploadImage, deleteImage };
